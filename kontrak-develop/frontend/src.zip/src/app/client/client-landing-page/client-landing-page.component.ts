import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-client-landing-page',
  templateUrl: './client-landing-page.component.html',
  styleUrls: ['./client-landing-page.component.scss']
})
export class ClientLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
 

}
