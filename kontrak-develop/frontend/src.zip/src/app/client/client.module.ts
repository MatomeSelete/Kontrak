import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientComponent } from './client/client.component';
import { RouterModule, Routes } from '@angular/router';
import { NavbarcComponent } from './navbarc/navbarc.component';
import { ClientLandingPageComponent } from './client-landing-page/client-landing-page.component';
import { CreatejobComponent } from './components/createjob/createjob.component';
import {DialogModule} from 'primeng/dialog';
import {ConfirmPopupModule} from 'primeng/confirmpopup';

import { ToastModule } from "primeng/toast";
import { ButtonModule } from "primeng/button";

import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmationService, MessageService} from 'primeng/api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GalleryComponent } from './gallery/gallery.component';
import { TrackerComponent } from './tracker/tracker.component';
import { RequestQuoteComponent } from './request-quote/request-quote.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { DragDropModule}   from '@angular/cdk/drag-drop';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { RatingComponent } from './rating/rating.component';
import { ViewReviewsComponent } from './view-reviews/view-reviews.component';



const route: Routes = [
  {
    path: 'client', component: ClientComponent, children: [
      { path: 'navbar', component: NavbarcComponent },
      { path: 'landingPage', component: ClientLandingPageComponent },
      { path: 'job', component: CreatejobComponent },
      { path: 'app-request-quote', component: RequestQuoteComponent },
      { path: 'gallery', component: GalleryComponent },
      {path: 'userProfile', component: UserProfileComponent},
      {path:'tracker/:id', component:TrackerComponent},
    ]
  }
]

@NgModule({
  declarations: [
    ClientComponent,
    NavbarcComponent,
    ClientLandingPageComponent,
    CreatejobComponent,
    TrackerComponent,
    RequestQuoteComponent,
    GalleryComponent,
    UserProfileComponent,
    RatingComponent,ViewReviewsComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    ReactiveFormsModule,
    FormsModule,
    DragDropModule,
    BrowserAnimationsModule,
    ConfirmPopupModule,
    DialogModule,
    ToastModule,
    ConfirmDialogModule



  ], 
   providers: [ConfirmationService,MessageService],
  
})
export class ClientModule { }
