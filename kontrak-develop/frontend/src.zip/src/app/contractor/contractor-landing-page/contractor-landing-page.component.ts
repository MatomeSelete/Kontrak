import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contractor-landing-page',
  templateUrl: './contractor-landing-page.component.html',
  styleUrls: ['./contractor-landing-page.component.scss']
})
export class ContractorLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
