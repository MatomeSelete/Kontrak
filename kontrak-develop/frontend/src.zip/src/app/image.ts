export interface Image {
}
