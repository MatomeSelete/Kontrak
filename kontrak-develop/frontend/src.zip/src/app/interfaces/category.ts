export interface Category {
   category_name :string;
    
}
