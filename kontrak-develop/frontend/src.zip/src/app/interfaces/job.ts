export interface Job {
    category : string;
    subCategory : string;
    location : string;
    description: string;
    image: string;
}

