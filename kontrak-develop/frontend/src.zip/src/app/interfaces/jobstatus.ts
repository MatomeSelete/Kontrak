export interface JobStatus {
    job_id: number;
    description: string;
    status: string;
    firstname: string
}