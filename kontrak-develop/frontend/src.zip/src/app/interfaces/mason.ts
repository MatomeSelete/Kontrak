export interface Mason {
}
