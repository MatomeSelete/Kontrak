export interface SubCategory {

    category_id : number ;

}
