export interface Todo {
    task_id: number;
    task_name: string;
    task_status: string;
    user_id?: number;
    job_id: number
  }