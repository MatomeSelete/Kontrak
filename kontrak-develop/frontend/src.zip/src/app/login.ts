export interface Login {
    email: String;
    password: String;
}
