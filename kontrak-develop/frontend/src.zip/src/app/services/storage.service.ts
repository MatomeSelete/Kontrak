import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
 contractor_id :any

 filterDails:any
 job_id :any
 task_id:any
  constructor() { }
}
