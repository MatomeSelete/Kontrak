export const environment = {
  baseUrl : '10.1.0.225:5400',
  production: true
};
